<?php // GIF89a
    echo "<pre>";
    echo htmlspecialchars(file_get_contents("web-serveur/ch51/index.php"));
    echo "</pre>";
?>